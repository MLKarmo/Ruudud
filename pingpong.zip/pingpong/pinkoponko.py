import pygame, sys
pygame.init()

#Ekraani uurus ja nimed
screenX = 640
screenY = 480
screen = pygame.display.set_mode([screenX, screenY])
pygame.display.set_caption("DVD")
posX, posY = 0, 0

#kell
clock = pygame.time.Clock()
speedX, speedY = 16, 16

#Ekraani taust
screen.fill([240, 180, 210])

#pall
pall = pygame.Rect(posX, posY, 20, 20)
pallImage = pygame.image.load("ball.png")
pallImage = pygame.transform.scale(pallImage, [pall.width, pall.height])

#platform
platformX = 120
platformY = 300
platformSpeedX = 8
platform = pygame.Rect(posX, posY, 120, 20)
platformImage = pygame.image.load("pulk.png")
platformImage = pygame.transform.scale(platformImage, [platform.width, platform.height])


gameover = False
while not gameover:
    
    clock.tick(30)
    
    #mängu sulgemine ristist
    event = pygame.event.poll()
    if event.type == pygame.QUIT:
        break
    
    #palli liikumine
    pall = pygame.Rect(posX, posY, 20, 20)
    screen.blit(pallImage,pall)
    
    posX += speedX
    posY += speedY

    if posX > screenX-pallImage.get_rect().width or posX < 0:
        speedX = -speedX
 
    if posY > screenY-pallImage.get_rect().height or posY < 0:
        speedY = -speedY
        
    #põrkamine platformilt
    platform = pygame.Rect(platformX, platformY, 120, 20)
    if pall.colliderect(platform) and speedY > 0 and pall.bottom <= platform.top + 10:
        speedY = -speedY
        
        
    #platformi liikumine
    platformX += platformSpeedX

    if platformX > screenX - platform.width or platformX < 0:
        platformSpeedX = -platformSpeedX
    


 # Draw everything
    screen.fill([240, 180, 210])
    pall = pygame.Rect(posX, posY, 20, 5)
    screen.blit(pallImage, pall)

    platform = pygame.Rect(platformX, platformY, 120, 20)
    screen.blit(platformImage, platform)

    pygame.display.flip()
pygame.quit()


#GITHUB LINK
#