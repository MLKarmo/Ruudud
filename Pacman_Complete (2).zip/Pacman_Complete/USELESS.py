import pygame
import sys

# Initialize Pygame
pygame.init()

# Set up display
screen = pygame.display.set_mode((448, 576))  # You can change the window size
pygame.display.set_caption('Game with Overlay')

# Load the overlay image
overlay_image = pygame.image.load('start.png')
overlay_image = pygame.transform.scale(overlay_image, (448, 576))  # Resize to match window

# Define button properties
button_font = pygame.font.Font(None, 40)
button_color = (240, 220, 80)
button_hover_color = (200, 80, 40)
start_button_rect = pygame.Rect(120, 450, 200, 30)
quit_button_rect = pygame.Rect(120, 500, 200, 30)

def draw_button(screen, rect, text, font, color):
    pygame.draw.rect(screen, color, rect)
    text_surface = font.render(text, True, (0, 0, 0))
    text_rect = text_surface.get_rect(center=rect.center)
    screen.blit(text_surface, text_rect)

# Game loop control
overlay_visible = True

# Main game loop
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if start_button_rect.collidepoint(event.pos):
                overlay_visible = False
            elif quit_button_rect.collidepoint(event.pos):
                pygame.quit()
                sys.exit()
    
    screen.fill((0, 0, 0))  # Fill the screen with black before drawing other elements
    
    if overlay_visible:
        screen.blit(overlay_image, (0, 0))
        
        # Draw buttons
        mouse_pos = pygame.mouse.get_pos()
        draw_button(screen, start_button_rect, 'Start', button_font, button_hover_color if start_button_rect.collidepoint(mouse_pos) else button_color)
        draw_button(screen, quit_button_rect, 'Quit', button_font, button_hover_color if quit_button_rect.collidepoint(mouse_pos) else button_color)
    
    pygame.display.flip()

pygame.quit()
