import pygame, sys, random
pygame.init()

#Ekraani uurus ja nimed
screenX = 640
screenY = 480
screen = pygame.display.set_mode([screenX, screenY])
pygame.display.set_caption("VROOM VROOM!")

#Ekraani pilt
bg = pygame.image.load("bg_rally.jpg")

#Kell, selle abil saab kasutada frame rate-i
clock = pygame.time.Clock()

#Sõidutee ääred
road_left = 170
road_right = 470

#Autod ja nende suurus
blue_car = pygame.image.load("f1_blue.png")
blue_car = pygame.transform.scale(blue_car, [60, 110])
red_car = pygame.image.load("f1_red.png")
red_car = pygame.transform.scale(red_car, [60, 110])

#Alg positsioonid
red_car_x = 280
red_car_y = 350
blue_car_x = 360
blue_car_y = -50

#Font ja algus skoor
score = 0
font = pygame.font.SysFont(None, 36)

#Mäng 
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
            
#Sinise auto kiirus   
    blue_car_y += 5
    
#Kui snine auto liigub kaugemale kui ekraaniY liigub ta tagasi algusesse, suvalisse kohta sõiduteel.
    if blue_car_y > screenY:
        blue_car_y = -100
        blue_car_x = random.randint(road_left, road_right)
        
#Kui auto jõuab tee lõppu, saab punane auto ühe punkti
        score += 1
    
    
#Ekraan ja autod joonistatakse ekraanile    
    screen.blit(bg, (0, 0))

    
    screen.blit(red_car, (red_car_x, red_car_y))

   
    screen.blit(blue_car, (blue_car_x, blue_car_y))
    
#Igakord kui sinine auto sõidab üle ekraani ääre, saab punane auto ühe punkti
    score_text = font.render("Score: " + str(score), True, (255, 255, 255))
    screen.blit(score_text, (20, 20))

    
#uuendab ekraani
    pygame.display.flip()

 #Kui mitu frame sekundis
    clock.tick(60)