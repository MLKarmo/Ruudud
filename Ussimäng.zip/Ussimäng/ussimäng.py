import pygame
import sys
import time
import random

pygame.init()

#Muusika
pygame.mixer.music.load("8bit.mp3")
pygame.mixer.music.play(-1)  

#Ekraani suurus ja nimi
screenX = 720
screenY = 720
screen = pygame.display.set_mode([screenX, screenY])
pygame.display.set_caption("ussike")

# Taust
bg = pygame.image.load("gamescreen.jpg")
screen.blit(bg, (0, 0))

# End screens
end_screen1 = pygame.image.load("end1.png")
end_screen2 = pygame.image.load("end2.png")

# Start screen image
start_screen = pygame.image.load("snakescreen.jpg")

# Ussikese seaded
snake_color = (0, 140, 70)
snake_block = 15
snake = [(100, 100), (90, 100), (80, 100)]
direction = 'RIGHT'
clock = pygame.time.Clock()
snake_speed = 50
segment_spacing = 3  # Adjust this value to make the circles closer

# Põõsa animatsioon
pic1 = pygame.image.load("pic1.png")
pic2 = pygame.image.load("pic2.png")
pic3 = pygame.image.load("pic3.png")
animation_frames = [pic1, pic2, pic3]

# Suu animatsioon
teeth1 = pygame.image.load("teeth1.png")
teeth2 = pygame.image.load("teeth2.png")
teeth_frames = [teeth1, teeth2]

# Putukad
food_image = pygame.transform.scale(pygame.image.load("putukas.png"), (20, 20))

# Ussikese suurus
def draw_snake(snake_list):
    for block in snake_list:
        pygame.draw.circle(screen, snake_color, (block[0], block[1]), snake_block // 2)

# Animatsiooni mängimine peale ussi põgenemist
def display_animation(x, y):
    for frame in animation_frames:
        screen.blit(bg, (0, 0))
        draw_snake(snake)
        screen.blit(frame, (x - 25, y - 25))  # Adjust position to center the animation
        pygame.display.update()
        time.sleep(0.2)

# Ussi suu
def display_head_animation(x, y, current_time):
    frame_index = (current_time // 500) % len(teeth_frames)
    frame = teeth_frames[frame_index]
    screen.blit(frame, (x - frame.get_width() // 2, y - frame.get_height() // 2))

# Ekraani piirid
def generate_point():
    x = random.randint(60, screenX - 60)
    y = random.randint(60, screenY - 60)
    return x, y

# Timer mis resettib peale putuka söömist
bug_timer = pygame.time.get_ticks()  # Current time in milliseconds
bug_interval = 3000  # Interval in milliseconds (3 seconds) to generate a new bug
start_time = 0  # Start time of the game

# Font for timer display
font = pygame.font.SysFont("Courier", 36)

# Text variables
text_color = (255, 255, 255)
text_toggle_time = pygame.time.get_ticks()

# Display start screen until SPACE key is pressed
show_start_screen = True
show_text = True
while show_start_screen:
    screen.blit(start_screen, (0, 0))
    if show_text:
        current_time = pygame.time.get_ticks()
        if (current_time - text_toggle_time) // 1000 % 2 == 0:
            text_color = (0, 0, 0)  # Change text color to black
        else:
            text_color = (255, 255, 255)  # Change text color to white
        text = font.render("PRESS -Space- to start", True, text_color)
        screen.blit(text, ((screenX - text.get_width()) // 2, screenY - text.get_height() - 20))
    pygame.display.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                show_start_screen = False
                show_text = False
                start_time = pygame.time.get_ticks()  # Start the timer when the start screen is hidden

# Load high score
try:
    with open("high_score.txt", "r") as file:
        high_score = int(file.read())
except FileNotFoundError:
    high_score = 0

# Main game loop
running = True
food = generate_point()
score = 0  # Punktid
bugs_eaten = 0  # Söödud putukad
while running:
    current_time = pygame.time.get_ticks()  
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT and direction != 'RIGHT':
                direction = 'LEFT'
            elif event.key == pygame.K_RIGHT and direction != 'LEFT':
                direction = 'RIGHT'
            elif event.key == pygame.K_UP and direction != 'DOWN':
                direction = 'UP'
            elif event.key == pygame.K_DOWN and direction != 'UP':
                direction = 'DOWN'

    # Ussikese liigutamine
    x, y = snake[0]
    if direction == 'UP':
        y -= segment_spacing
    elif direction == 'DOWN':
        y += segment_spacing
    elif direction == 'LEFT':
        x -= segment_spacing
    elif direction == 'RIGHT':
        x += segment_spacing
    new_head = (x, y)

    # Check for boundary collision
    if x < 60 or x >= screenX - 60 or y < 60 or y >= screenY - 60:
        display_animation(x, y)  # ussi põgenemise animatsuioon
        # Ussi keha kadumine
        while len(snake) > 0:
            snake.pop()
            screen.blit(bg, (0, 0))
            draw_snake(snake)
            pygame.display.update()
            time.sleep(0.01)
        # Update high score
        if score > high_score:
            high_score = score
            with open("high_score.txt", "w") as file:
                file.write(str(high_score))
        # Display end screen 2
        screen.blit(end_screen2, (0, 0))
        # Display bugotations, score, and high score on end screen 2
        font_big = pygame.font.SysFont("Courier", 48)
        score_text = font_big.render("Score: " + str(score), True, (255, 255, 255))
        bugs_text = font_big.render("Bugotations: " + str(bugs_eaten), True, (255, 255, 255))
        high_score_text = font_big.render("High Score: " + str(high_score), True, (255, 255, 255))
        screen.blit(score_text, ((screenX - score_text.get_width() - 10, 60)))
        screen.blit(bugs_text, ((screenX - bugs_text.get_width() - 10, 10)))
        screen.blit(high_score_text, ((screenX - high_score_text.get_width() - 10, 110)))
        pygame.display.update()
        time.sleep(3)  # Adjust the duration of the end screen
        running = False  # End the game

    snake.insert(0, new_head)

    # Generate a new bug if the time interval has elapsed
    if current_time - bug_timer > bug_interval:
        food = generate_point()  # Generate new bug
        bug_timer = current_time  # Reset the timer

       # Check if snake eats bug
    if abs(new_head[0] - food[0]) < snake_block and abs(new_head[1] - food[1]) < snake_block:
        food = generate_point()  # Generate new bug
        # Calculate score based on elapsed time and add it to the score
        score += (current_time - start_time) // 1000 if start_time != 0 else 0
        snake.extend([snake[-1]] * 10)  # Grow the snake by 10 circles
        # Reset the start time
        start_time = pygame.time.get_ticks()
        # Increase snake speed
        snake_speed += 1

    # Pop the tail of the snake
    snake.pop()

    # Check if the timer reaches 10 seconds
    elapsed_time = (current_time - start_time) // 1000 if start_time != 0 else 0
    if elapsed_time >= 10:
        # Update high score
        if score > high_score:
            high_score = score
            with open("high_score.txt", "w") as file:
                file.write(str(high_score))
        # Display end screen 1
        screen.blit(end_screen1, (0, 0))
        # Display bugotations, score, and high score on end screen 1
        font_big = pygame.font.SysFont("Courier", 48)
        score_text = font_big.render("Score: " + str(score), True, (255, 255, 255))
        bugs_text = font_big.render("Bugotations: " + str(bugs_eaten), True, (255, 255, 255))
        high_score_text = font_big.render("High Score: " + str(high_score), True, (255, 255, 255))
        screen.blit(score_text, ((screenX - score_text.get_width() - 10, 60)))
        screen.blit(bugs_text, ((screenX - bugs_text.get_width() - 10, 10)))
        screen.blit(high_score_text, ((screenX - high_score_text.get_width() - 10, 110)))
        pygame.display.update()
        time.sleep(3)  # Adjust the duration of the end screen
        running = False  # End the game

    # Redraw screen
    screen.blit(bg, (0, 0))
    draw_snake(snake)

    # Draw bug
    screen.blit(food_image, food)

    # Display head animation
    display_head_animation(snake[0][0], snake[0][1], current_time)

    # Calculate elapsed time and render it on the screen
    text = font.render("Time: " + str(elapsed_time), True, (255, 255, 255))
    screen.blit(text, (10, 10))

    # Display score on the screen
    score_text = font.render("Score: " + str(score), True, (255, 255, 255))
    screen.blit(score_text, (screenX - score_text.get_width() - 10, 60))

    # Display bugs eaten count
    bugs_text = font.render("Bugotations: " + str(bugs_eaten), True, (255, 255, 255))
    screen.blit(bugs_text, (screenX - bugs_text.get_width() - 10, 10))

    pygame.display.update()
    clock.tick(snake_speed)

# Close the game
pygame.quit()
sys

#https://www.edureka.co/blog/snake-game-with-pygame/
#https://gist.github.com/arpit-omprakash/1899f7ba4330cb2f327fda0a4d66c583